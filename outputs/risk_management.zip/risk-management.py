def handle(event, context):
    print("Hello World")