def handle(event, context):
    print(event)